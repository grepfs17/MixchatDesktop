import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseEnvFile } from "../src/main/mixchat-server.mjs";

const projectRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
const mixchatRoot = process.env.MIXCHAT_DIR
  ? path.resolve(process.env.MIXCHAT_DIR)
  : path.resolve(projectRoot, "..", "Mixchat");

// Desktop build profile. When present, the Mixchat bundle is built in
// "desktop" mode: public-client OAuth (Twitch Device Code, Google PKCE) and
// NO client secrets baked in. See .env.desktop.example.
const desktopEnvFile = path.join(projectRoot, ".env.desktop");
const desktopMode = existsSync(desktopEnvFile);

const env = { ...process.env };
if (desktopMode) {
  Object.assign(env, parseEnvFile(desktopEnvFile), {
    PUBLIC_APP_PLATFORM: "desktop",
  });
  // Never embed secrets in a distributed desktop build, even if the developer's
  // Mixchat/.env defines them. (TWITCH_GQL_CLIENT_ID is a public Twitch web
  // client id with a built-in fallback, so it is left as-is.)
  env.TWITCH_CLIENT_SECRET = "";
  env.YOUTUBE_CLIENT_SECRET = "";
  console.log(
    "[build-mixchat] desktop mode: PUBLIC_APP_PLATFORM=desktop, client secrets stripped",
  );
} else {
  console.warn(
    "[build-mixchat] No .env.desktop found — building in web mode; client secrets WILL be baked.",
  );
}

const res = spawnSync("pnpm", ["--dir", mixchatRoot, "build"], {
  stdio: "inherit",
  env,
});
process.exit(res.status ?? 1);
